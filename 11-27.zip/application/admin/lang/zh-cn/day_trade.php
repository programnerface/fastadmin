<?php

return [
    'Order_date'     => '日期',
    'Payment_amount' => '交易额',
    'Order_count'    => '订单数',
    'Order_zelle'    => 'Zelle',
    'Order_cash'     => 'Cash',
    'Order_venmo'    => 'Venmo',
    'Order_square'   => 'Square'
];
