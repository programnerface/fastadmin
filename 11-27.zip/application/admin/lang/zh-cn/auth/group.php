<?php

return [
    'The parent group can not be its own child'                            => '父组别不能是自身的子组别',
    'The parent group can not found'                                       => '父组别未找到',
    'Group not found'                                                      => '组别未找到',
    'Can not change the parent to child'                                   => '父组别不能是它的子组别',
    'Can not change the parent to self'                                    => '父组别不能是它自己',
    'You can not delete group that contain child group and administrators' => '你不能删除含有子组和管理员的组',
    'The parent group exceeds permission limit'                            => '父组别超出权限范围',
    'The parent group can not be its own child or itself'                  => '父组别不能是它的子组别及本身',
];
