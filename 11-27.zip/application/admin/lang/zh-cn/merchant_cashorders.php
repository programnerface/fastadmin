<?php

return [
    'Merchant_name' => '商户名称',
    'Order_num'     => '订单号',
    'Order_date'    => '日期',
    'Payer'         => '付款人',
    'Product_name'  => '产品',
    'Price'         => '金额',
    'Identifier'    => '确认码',
    'Fees'          => '手续费',
    'Amount'        => '应结算',
    'Payment_img'   => '支付截图',
    'Carrier'       => '承运商',
    'Waybill_num'   => '运单号',
    'Order_status'  => '订单状态'
];
