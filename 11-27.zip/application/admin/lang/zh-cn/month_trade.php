<?php

return [
    'Month'          => '月份',
    'Payment_amount' => '交易额',
    'Order_count'    => '订单数'
];
