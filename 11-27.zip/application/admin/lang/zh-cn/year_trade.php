<?php

return [
    'Order_type'     => '类型',
    'Payment_amount' => '交易额',
    'Order_count'    => '订单数'
];
